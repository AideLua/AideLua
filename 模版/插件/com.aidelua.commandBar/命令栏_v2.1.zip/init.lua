appname="命令栏"--插件名
packagename="com.aidelua.commandBar"--插件包名
appver="2.1"
appcode=2199
minemastercode=50000--最低编辑器版本号
targetmastercode=59999--目标编辑器版本号
mode="plugin"--模式：插件
supported={"aidelua","eddelua"}
