name="我的复杂库"
keys={--格式化的关键词
  defaultImport={"MyMainTools"},
}

delete={--删除的文件
}

format={--格式化的文件
}

--[[
截止 2021.1.27 ，已规定的Key有：（“--”后为示例）
应用名：appName
包名：appPackageName
附加Library（config.lua）：appIncludeLua --{"project:Jesse205Library"}
附加Library（build.gradle）：appDependencies --{"api project(':Jesse205Library')"},
附加Library（settings.gradle）：appInclude --{":Jesse205Library"}
编译Lua：compileLua --true
app默认主题（xml）：appTheme --"@style/Theme.Jesse205.DayNight"
application代码：am_application  --{'<meta-data android:name="android.max_aspect" android:value="4"/>'}
默认icon路径：appIcon --"@mipmap/ic_launcher"
默认导入：defaultImport --{"EMUIStyle"}
]]
