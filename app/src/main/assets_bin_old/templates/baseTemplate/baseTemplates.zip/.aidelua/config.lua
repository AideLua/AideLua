tool={
  version="1.1",
}
appName="{{appName}}"--应用名称
packageName="{{appPackageName}}"--应用包名
debugActivity="{{appLuaActivity}}"--调试Activity

include={"project:app",{{appIncludeLua}}"project:androlua"}--导入，第一个为主程序
main="app"--老版本
compileLua={{compileLua}}--编译Lua

--相对路径位于工程根目录下
icon={
  day="ic_launcher-aidelua.png",--图标
  night="ic_launcher_night-aidelua.png",--暗色模式图标
}