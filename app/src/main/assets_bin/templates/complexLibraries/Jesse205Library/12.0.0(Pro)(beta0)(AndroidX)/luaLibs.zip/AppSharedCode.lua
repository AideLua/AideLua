--进入Activity时执行
--[[
--在内部打开浏览器，如果有内置浏览器就重写这个方法
function openUrl(url)
end
]]