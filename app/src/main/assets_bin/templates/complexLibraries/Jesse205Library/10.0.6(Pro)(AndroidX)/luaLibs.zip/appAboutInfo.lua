--import "androidx.core.content.res.ResourcesCompat"

appInfo={
  {
    name=R.string.app_name,--名称
    message="一款很棒的APP",--简介
    icon=R.mipmap.ic_launcher,--图标
    --typeface=ResourcesCompat.getFont(activity,R.font.myfont),--名称字体
    --nameColor=theme.color.colorAccent,--名称颜色
  },
}

--开发信息
developers={
  {
    name="Eddia",--"名称"
    qq=2140125724,--"QQ号"
    message="Aide Lua 开发者",--"简介"
  },
}

--启用开源许可
openSourceLicenses=true

--多个QQ群
qqGroups={
  {
    name="Edde 综合群",
    id=708199076,
  },
}

--单个QQ群
qqGroup=708199076

--donateUrl="https://afdian.net/@Jesse205"--捐赠链接
donateImage=R.drawable.donate_weichat--捐赠图片
--copyright="No Copyright"
