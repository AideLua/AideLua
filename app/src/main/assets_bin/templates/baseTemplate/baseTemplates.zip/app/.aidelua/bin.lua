function beforePack(path)
--这里写当打包时候执行的东西
end