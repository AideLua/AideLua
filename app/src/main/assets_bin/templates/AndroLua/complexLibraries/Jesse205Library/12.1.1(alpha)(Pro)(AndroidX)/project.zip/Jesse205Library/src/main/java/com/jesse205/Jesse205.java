package com.jesse205;

import android.content.Context;

public class Jesse205 {
	private final Context mContext;
	public Jesse205(Context context) {
		mContext = context;
	}

	public Context getContext() {
		return mContext;
	}
}
