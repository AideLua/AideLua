import "initApp"
local context=jesse205.context


if getSharedData("theme_darkactionbar")==nil then
  setSharedData("theme_darkactionbar",false)
end
