--import "androidx.core.content.res.ResourcesCompat"

appInfo={
  {
    name=R.string.app_name,
    message="一款很棒的APP",
    icon=R.mipmap.ic_launcher,
    --typeface=ResourcesCompat.getFont(activity,R.font.yunchu),
  },
}

developers={
  {
    name="Eddia",
    qq=2140125724,
    message="Aide Lua 开发者",
  },
}

openSourceLicenses=true

qqGroups={
  {
    name="Edde 综合群",
    id=708199076,
  },
}
qqGroup=708199076

--donateUrl="https://afdian.net/@Jesse205"
donateImage=R.drawable.donate_weichat
--copyright="No Copyright"
