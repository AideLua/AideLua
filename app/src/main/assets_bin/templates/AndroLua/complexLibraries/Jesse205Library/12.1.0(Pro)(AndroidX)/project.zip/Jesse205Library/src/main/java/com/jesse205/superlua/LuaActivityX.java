package com.jesse205.superlua;

import android.content.res.Resources;

/**
 * Created by Administrator on 2018/06/10 0010.
 */

public class LuaActivityX extends LuaActivity {

}
